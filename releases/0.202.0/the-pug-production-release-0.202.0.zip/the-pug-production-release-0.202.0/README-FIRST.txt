The Pug production release package

Install order:
1. Install/verify the WordPress plugin ZIP on production.
2. Install/verify the pug-arcade-commerce-v2 theme ZIP on production.
3. Install and start pug-local-sync-middleman-server.zip on the in-store host machine.
4. Install employee-app/the-pug-employee-app-*.exe on staff stations.
5. Install customer-kiosk/the-pug-customer-kiosk-*.exe on customer kiosk stations.

Connectivity:
- Employee and kiosk apps auto-discover the middleman over UDP pug-local-sync-discovery-v1 on port 8788.
- If auto-discovery is blocked, enter the middleman URL manually, for example http://SERVER-IP:8787.
- WordPress remains the source of truth; the LAN server caches and queues while offline.

Final release gate:
Run npm.cmd run production:verify-active-syncs before signoff.

Bundled app installer: the-pug-local-app-0.202.0.exe
