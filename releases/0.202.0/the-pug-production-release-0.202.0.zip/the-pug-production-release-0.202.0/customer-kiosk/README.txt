The Pug customer kiosk

Use this package on customer-facing lookup/order stations.
It is configured as the kiosk package and should be paired to the same local middleman server as staff machines.
The app auto-discovers the local middleman server over UDP port 8788.
If discovery is blocked, enter the middleman URL manually, for example http://SERVER-IP:8787.
