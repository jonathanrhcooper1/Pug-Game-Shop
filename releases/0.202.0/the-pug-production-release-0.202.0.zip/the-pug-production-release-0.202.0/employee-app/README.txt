The Pug employee app

Use this package on staff machines for inventory, customer, trade-in, fulfillment, reporting, and sync work.
The app auto-discovers the local middleman server over UDP port 8788.
If discovery is blocked, enter the middleman URL manually, for example http://SERVER-IP:8787.
